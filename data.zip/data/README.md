# RE-E2E data

This directory contains the data retained for the RE-E2E benchmark:

- `project_summary_llm_processed/`: 29 concise project descriptions used as model inputs.
- `requirement_specifications_ieee_1998/`: 29 human-written SRS documents normalized to IEEE 830-1998 sections.
- `requirement_specifications_ieee_2018/`: 18 human-written SRS documents normalized to IEEE 29148-2018 sections.

Each requirement specification is stored as CSV with its section hierarchy and normalized textual content. Generated model completions and judge outputs are intentionally excluded.

